# Malicious Website Blocker
This is a project to block malicious websites and allow access using a passcode.
