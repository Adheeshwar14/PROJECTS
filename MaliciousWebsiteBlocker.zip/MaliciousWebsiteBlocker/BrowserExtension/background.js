// Background script for extension
