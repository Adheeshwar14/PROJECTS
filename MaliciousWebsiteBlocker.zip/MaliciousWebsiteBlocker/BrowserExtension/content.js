// Content script for extension
